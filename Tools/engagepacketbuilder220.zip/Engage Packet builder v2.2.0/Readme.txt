                     ==================================
                        Engage Packet builder v2.2.0
                                (13/03/2007)
                                   -----
                         Packet builder for Windows
                     ==================================


 Content
---------
 1. Description
 2. System requirements
 3. Installation
 4. Versions history
 5. Scripts
 6. Known BUGs
 7. Terms of use
 8. Reporting problems
 9. Greetings


 1. Description
----------------

Powerful and scriptable packet builder for Windows platform.

Platform: Windows XP/2000
Version: 2.2.0

Author : EngageSecurity - G. Wilmes
Contact: SupportPacket@EngageSecurity.com (you can write in French or English)

Features :
----------
* Packet injection starting from link layer (MAC address spoofing), supporting following transport protocols :
   - TCP (RFC 793)
   - UDP (RFC 768)
   - ICMP (RFC 792)
* Custom payload in hex format / ASCII format
   - Payload data, with input file support
     (0 termination string specified if the string is terminated by \0, in that case the 0 is appended at the end)
   - ASCII to Hex converted built-in
     (Data can be set to hexadecimal for input by inserting '0x' at the beginning (hexa : 0xA5bC FF   e7  7 B ...) )
* Scripting engine
   - Easy to learn scripting language
   - Full control without using the frontend
* Based on Libnet library
* Great for Firewall and IDS testing
   - SYN-Floods can be generated very easy
   - Build "strange" packets (SYN-FIN for example)
   - Full control over sequence and acknowledge number, window size and urgent pointer
* Multiple language support

Note : - With WinPcap 3.1 installed, under 2000/XP/2003 we have added a new fake NdisWan adapter, useful to
         capture LCP/NCP PPP packet, for example. This adapter is always listed (if you have enough privileges),
         even if you don't have any PPP/VPN/... connection established.
         ( * Please note that this feature is experimental )
       - Q: What is that BlackBox.dll stuff ?
         A: BlackBox is a Win32 DLL that can help track exceptions that happen at runtime, and can provide
            a stack trace that shows where the error occured. It is conceptually similar to the TalkBack module
            that Mozilla uses in their builds to handle error reporting.


 2. System requirements
------------------------

  - Windows (versions supported by WinPcap 3.1/4.0)
  - WinPcap 3.1 or 4.0 , http://www.winpcap.org/install/
    * WinPcap 3.1 recommended


 3. Installation
-----------------

Decompress the archive somewhere on your hard drive and run the executable.


 4. Scripts
------------

Commands, settings and variables, are not case sensitive.

For examples, 'Scripts/Example vx.xx.rsb' and 'Scripts/Example - Dynamic dialog vx.xx.rsb'

Commands :
----------
  !ECHO ON			Enables the default echo in the display box
  !ECHO OFF			Disables echo and let you custom what u want to display
  !DISPLAY=Hello world !	
				Will display "Hello world !" in the display box of the prog
  !SLEEP 5000		Will wait 5 seconds before to execute next line
  !SEND x TCP		Send x TCP packets with current config (same for UDP & ICMP)
  !LOOP			Restart the script (goes to the first line)
  !BEGINLOOP $variable FROM x TO x (STEP x / RANDOM)
				Begin the loop block
  !ENDLOOP			End the loop block

Settings :
----------
 Ethernet fields :
 -----------------
  MACDESTINATION(MAC)  ( or MACDST(MAC) )
  MACSOURCE(MAC)  ( or MACSRC(MAC) )

 IP fields :
 -----------
  IPSOURCE(IP)  ( or IPSRC(IP) )
  PORTSOURCE(Port)  ( or PORTSRC(Port) )  (see RFC)
  IPDESTINATION(IP)  ( or IPDST(IP) )
  PORTDESTINATION(Port)  ( or PORTDST(Port) )  (see RFC)
  IPHEADERSIZE(integer)
  IPTOTALLENGTH(integer)
  IPIDENTIFICATION(integer)  ( or IPIDENT(integer) )
  IPFRAGMENTATION_DF(integer)  ( or IPFRAG_DF(integer) )
  IPFRAGMENTATION_MF(integer)  ( or IPFRAG_MF(integer) )
  IPOFFSET(integer)
  IPTTL(integer)
  IPCHECKSUM(integer)

 TCP fields :
 ------------
  TCPSEQUENCE(integer)  ( or TCPSEQ(integer) )
  TCPACKNOWLEDGE(integer)  ( or TCPACK(integer) )
  TCPOFFSET(integer)
  URG(0/1) ; ACK(0/1) ; PSH(0/1) ; RST(0/1) ; SYN(0/1) ; FIN(0/1)
  TCPWINDOW(integer)
  TCPURGENT(integer)
  TCPCHECKSUM(integer)
  TCPDATA(string)

 UDP fields :
 ------------
  UDPCHECKSUM(integer)
  UDPDATA(string)

 ICMP fields :
 -------------
  ICMPTYPE(integer)
  ICMPCODE(integer)
  ICMPIDENTIFIER(integer)  ( or ICMPIDENT(integer) )
  ICMPSEQUENCE(integer)  ( or ICMPSEQ(integer) )
  ICMPCHECKSUM(integer)
  ICMPDATA(string)


 5. Versions history
---------------------

Engage Packet builder v2.2.0 : (13/03/2007)
  + Winpcap 4.0 support

Engage Packet builder v2.1.0 : (15/01/2007)
  + Mini Webserver

Engage Packet builder v2.0.0 : (19/07/2006)
  + Improved auto-updating code
  + Microsoft's (SAPI) Speech API 5.1 support :
      To enable it, Configuration\Configuration.ini : in [General] section, add Speech=1
  * Minor bugfixes
  + Winpcap 3.0 and Winpcap 3.1 support (v3.1 recommended)
  + Added support for data file - with hexadecimal support (same format as data field)
  + Added support for IP options and TCP options, from file
  + WinPcap version visible in About
  * Scripts 'bugs' fixed
  * Source MAC bug fixed
  + Winpcap 3.1 support
  + Switching to Libnet 1.1.2.1
  * IP length fixed
  * Checksums are now correct (IP / TCP / UDP / ICMP)
  * Specify data offset was incorrect, x5 -> x4 bytes
  * Various bugs fixed for language support

Engage Packet builder v1.0.0 : (14/06/2003)
  * Current directory bug is now fixed
  + Auto-upgrade (you can find it in About)

Rafale X v1.31 : (18/10/2002)
  + Improved network interface selection
  + Posting of the network interface details
  + Specification of the MAC address for source and destination (Ethernet)
  + Specification of the total size (IP)

Rafale X v1.3 : (17/06/2002)
  + Switching to LibnetNT with W9x and NT support
  * Bug which was initializing the Id and Code fields to 0 has been fixed

Rafale X v1.2 : (12/06/2002)
  + Loop in the script
      ex:  !BEGINLOOP $PARAM3 FROM 100 TO 150 STEP 2
             !BEGINLOOP $PARAM4 FROM 200 TO 220
             (ou !BEGINLOOP $PARAM4 FROM 200 TO 220 STEP 1)
             (ou !BEGINLOOP $PARAM4 FROM 210 TO 200 STEP -3)
             (ou !BEGINLOOP $PARAM4 FROM 200 TO 220 RANDOM)
               IPSRC=192.168.$PARAM3.$PARAM4
             !ENDLOOP
           !ENDLOOP
  + Dynamic dialog box, created by the script
  + 'Set as IP Source' checked by default
  + DNS Resolving (Source IP and Destination IP)
  * Bug in the network interface that was resetting to the first item when changing the language is fixed
  * Bug in the ICMP Echo (the data field was not sent correctly) is now fixed
  + The data can now be set to hexadecimal for input by inserting '0x' at the beginning (hexa : 0xA5bC FF  e7  7 B...)
  + 0 termination string specified if the string is terminated by \0, in that case the 0 is appended at the end
  * Deactivation of the data field in ICMP if the former is not an Echo
  * Bug that was putting the fields to 0 (ICMP) has been fixed
  * Bug that was setting to 0 Identifier and Sequence fields while loading ICMP options has been fixed

Rafale X v1.1 : (12/03/2002)
  * Update of the Raw socket library (v3.00) 
  * Fixed the ICMP bug 
  + Windows XP detection 
  + Windows XP menu style support 
  + Size of IP data automatically updated following the data field 
  * Fixed the bug that was sending one more packet with scripts 
  * Fixed the bug that was forgetting some parameters in TCP parameters 
  * Desactivation of port fields while using ICMP 
  + Possibility to load options automatically 
  + Possibility to set the interface always on top 
  * Fixed the problem with SYN/ACK numbers (32bits) 
  + Choice to specify TCP data offset 
  * The bug in the 2 IP fragmentation flags is corrected 
  * Fixed the ident field, TTL and offsets in raw library 
  + Deactivation of the datasize field in IP header 
  + Updated and improved printing 

Rafale X v1.0 : (05/01/2002)
  - Initial release


 6. Known BUGs
---------------

May crash with WinPcap 4.0 under Vista.


 7. Terms of use
-----------------

This software is provided "as is", without any guarantee made as to its suitability or fitness for any particular use.
It may contain bugs, so use of this tool is at your own risk. We take no responsilbity for any damage that may
unintentionally be caused through its use.

You may not distribute Engage Packet builder in any form without express written permission of Engage Security.


 8. Reporting problems
-----------------------

If you encounter problems, please visit http://www.EngageSecurity.com and download the latest version to see if
the issue has been resolved.

If not, please send a bug report (---in French or English---) to :

	SupportPacket@EngageSecurity.com


 9. Greetings
--------------

 - U. Kistler, Switzerland
 - WinPcap (http://www.winpcap.org)
 - Libnet (http://www.packetfactory.net/projects/libnet/)
 - PJ Naughter for W3Mfc (http://www.naughter.com)
 - Vulnerabilite.com (http://www.vulnerabilite.com)

<EOF>